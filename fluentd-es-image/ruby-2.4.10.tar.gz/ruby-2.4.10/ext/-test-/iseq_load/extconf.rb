# frozen_string_literal: false
create_makefile("-test-/iseq_load")
